package musiclibrary;

/**
 *
 * @author Eskandar Atrakchi
 */
public class MusicLibraryApp {

    public static void main(String[] args) {
        
        MusicLibraryGUI mgui = new MusicLibraryGUI () ;
        //set the visibility to true 
        mgui.setVisible(true);
        
    }
}
